import { Component, Input } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styles: [
  ]
})
export class ListComponent {
  @Input() personList?: Array<string>;
  selected: string;
  by: string;

  constructor() {
    this.selected = "";
    this.by = "";
  }

  select(pName: string, e: Event) {
    this.selected = pName;
    e.preventDefault();
  }
}
