import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  @ViewChild("c1", { static: true })
  counter_one?: CounterComponent;

  @ViewChild("c2", { static: true })
  counter_two?: CounterComponent;

  @ViewChildren(CounterComponent)
  counters?: QueryList<CounterComponent>;

  pList: Array<string>;
  message: string;

  constructor() {
    this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
    this.message = "";
  }

  // ngAfterViewInit() {
  //   console.log(this.counter_one);
  // }

  p2_reset(counter: CounterComponent) {
    counter.reset();
  }

  p3_reset() {
    // console.log(this.counter_one);
    // console.log(this.counter_two);

    this.counter_one?.reset();
    this.counter_two?.reset();
  }

  reset_all() {
    // console.log(this.counters);
    if (this.counters) {
      for (const counter of this.counters) {
        counter.reset();
      }
    }
  }

  updateMessage(flag: boolean) {
    if (flag)
      this.message = "Max Click Reached, please Reset to restart...";
    else
      this.message = "";
  }
}