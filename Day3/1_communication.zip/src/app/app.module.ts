import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { HighlightDirective } from './directives/highlight.directive';
import { ListComponent } from './components/list/list.component';
import { CounterComponent } from './components/counter/counter.component';

@NgModule({
  declarations: [
    RootComponent,
    HighlightDirective,
    ListComponent,
    CounterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }