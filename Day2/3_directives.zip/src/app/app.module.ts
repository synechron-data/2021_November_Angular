import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { AssignTwoComponent } from './components/assign-two/assign-two.component';
import { ListComponent } from './components/list/list.component';
import { ChangeContentDirective } from './directives/change-content.directive';
import { IsAuthorizedDirective } from './directives/is-authorized.directive';
import { HighlightDirective } from './directives/highlight.directive';

@NgModule({
  declarations: [
    RootComponent,
    AssignTwoComponent,
    ListComponent,
    ChangeContentDirective,
    IsAuthorizedDirective,
    HighlightDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }