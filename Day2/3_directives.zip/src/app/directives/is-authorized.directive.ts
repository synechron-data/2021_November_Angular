import { Directive, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[isAuthorized]'
})
export class IsAuthorizedDirective implements OnInit {
  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainerRef: ViewContainerRef

  ) { }

  ngOnInit(): void {
    console.log(this.viewContainerRef);
    console.log(this.templateRef);

    // You can get the value for the below Flag from an Authorization Service
    // const flag = this.aService.isAUthorized;

    const flag = true;

    if (flag) {
      this.viewContainerRef.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainerRef.clear();
    }
  }
}