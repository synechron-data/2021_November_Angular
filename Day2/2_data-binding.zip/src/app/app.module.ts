import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { AssignTwoComponent } from './components/assign-two/assign-two.component';
import { AssignOneComponent } from './components/assign-one/assign-one.component';

@NgModule({
  declarations: [
    RootComponent,
    AssignTwoComponent,
    AssignOneComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }