import { Component } from "@angular/core";

@Component({
    selector: 'app-hello',
    template: `
        <h1>
            Hello World!
        </h1>
        <!-- <app-hi></app-hi>
        <app-hi></app-hi> -->

`
})
export class HelloComponent { }