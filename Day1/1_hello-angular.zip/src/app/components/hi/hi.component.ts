import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hi',
  template: `
    <h1>
      Hi World!
    </h1>
  `,
  styles: [
  ]
})
export class HiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
