import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'scomp',
  template: `
    <h3 class="text-warning">I am the Shared Component from Shared Module</h3>
  `,
  styles: [
  ]
})
export class ScompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
