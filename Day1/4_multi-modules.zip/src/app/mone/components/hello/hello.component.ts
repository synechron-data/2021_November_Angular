import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hello',
  template: `
    <h2 class="text-primary">Local Hello Component - MOneModule</h2>
  `,
  styles: [
  ]
})
export class HelloComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
