import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-one',
  template: `
    <h1 class="text-primary">Hello from Component One - Module One</h1>
    <hello></hello>
    <scomp></scomp>
  `,
  styles: [
  ]
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
