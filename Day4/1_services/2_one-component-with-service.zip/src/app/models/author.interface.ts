export interface Author {
    name: string;
    quote: string;
}