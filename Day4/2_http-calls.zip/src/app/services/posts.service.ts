import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "../models/post.model";
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";
import { environment } from 'src/environments/environment';

@Injectable()
export class PostsService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = environment.postsUrl;
    }

    // getAllPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getAllPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getAllPosts', []))
        )
    }

    private _handleError<T>(operation = 'operation', result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.error(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later');
        }
    }
}