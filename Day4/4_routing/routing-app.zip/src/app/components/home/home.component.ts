import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit, OnDestroy {
  constructor() { 
    console.log("Home Component Constructor...");
  }

  ngOnInit(): void {
    console.log("Home Component Initialized...");
  }

  ngOnDestroy(): void {
    console.log("Home Component Destroyed...");
  }
}
